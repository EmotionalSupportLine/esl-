
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, Appointment, CallState, Supporter, Notification, Shift, OpenShift, CallerNote, ApplicationState, MentorApplication, AffiliateResource, ConnectResult } from '../types';
import { INITIAL_SUPPORTERS, PAY_PER_CALL, INITIAL_OPEN_SHIFTS, INITIAL_AFFILIATE_RESOURCES } from '../constants';
import { supabase } from '../lib/supabaseClient';
import { voiceService } from '../services/geminiLiveService';

interface AppContextType {
  user: User | null;
  supporters: Supporter[];
  openShifts: OpenShift[];
  mentorApplications: MentorApplication[]; 
  notifications: Notification[];
  removeNotification: (id: string) => void;
  callBankBalance: number;
  login: (role: UserRole) => void;
  logout: () => void;
  donateToBank: (amount: number) => void;
  purchaseCredit: (amount: number) => void;
  subscribe: () => void;
  useCredit: () => boolean;
  activeCallState: CallState;
  setActiveCallState: (state: CallState) => void;
  appointments: Appointment[];
  scheduleAppointment: (supporterId: string, time: string) => void;
  toggleSupporterAvailability: (supporterId: string, forceState?: boolean) => void;
  connectToFirstAvailable: () => ConnectResult;
  supporterCashOut: () => void;
  addShift: (supporterId: string, day: string, time: string) => void;
  removeShift: (supporterId: string, shiftId: string) => void;
  createOpenShift: (day: string, time: string) => void;
  claimShift: (shiftId: string) => void;
  blockCaller: (callerId: string, reason: string) => void;
  currentConnectedSupporter: Supporter | null;
  saveCallerNote: (callerId: string, text: string) => void;
  getCallerNotes: (callerId: string) => Promise<CallerNote[]>;
  applicationState: ApplicationState;
  setApplicationState: (state: ApplicationState) => void;
  submitApplication: (app: MentorApplication) => void;
  updateApplicationStatus: (appId: string, status: 'APPROVED' | 'REJECTED') => void;
  affiliateResources: AffiliateResource[];
  justPaidForHumanDesign: boolean;
  setJustPaidForHumanDesign: (val: boolean) => void;
  requestCallback: (phoneNumber: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children?: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [supporters, setSupporters] = useState<Supporter[]>(INITIAL_SUPPORTERS);
  const [openShifts, setOpenShifts] = useState<OpenShift[]>(INITIAL_OPEN_SHIFTS);
  const [mentorApplications, setMentorApplications] = useState<MentorApplication[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [callBankBalance, setCallBankBalance] = useState<number>(45);
  const [activeCallState, setActiveCallState] = useState<CallState>(CallState.IDLE);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [currentConnectedSupporter, setCurrentConnectedSupporter] = useState<Supporter | null>(null);
  const [applicationState, setApplicationState] = useState<ApplicationState>(ApplicationState.NONE);
  const [affiliateResources] = useState<AffiliateResource[]>(INITIAL_AFFILIATE_RESOURCES);
  const [justPaidForHumanDesign, setJustPaidForHumanDesignState] = useState(false);

  const addNotification = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    const id = crypto.randomUUID();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 6000);
  };

  const toggleSupporterAvailability = async (supporterId: string, forceState?: boolean) => {
    const supporter = supporters.find(s => s.id === supporterId);
    if (!supporter) return;
    const newState = forceState !== undefined ? forceState : !supporter.isAvailable;

    if (user && user.id === supporterId && newState === true) {
      try {
        addNotification("Connecting to Twilio...", 'info');
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        await voiceService.initialize(user.id);
        
        voiceService.setIncomingCallHandler((call) => {
          voiceService.acceptIncomingCall(call);
          setActiveCallState(CallState.ACTIVE);
          addNotification("Incoming call! Connection active.", 'success');
        });

        setSupporters(prev => prev.map(s => s.id === supporterId ? { ...s, isAvailable: true } : s));
        addNotification("System Online. Ready for calls.", 'success');
      } catch (err: any) {
        console.error("Toggle Support Error:", err);
        let errorMsg = "Connection failed.";
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          errorMsg = "Microphone blocked. Please check your phone settings.";
        } else if (err.message?.includes('Variables')) {
          errorMsg = "Config Error: Twilio keys missing in Vercel settings.";
        } else {
          errorMsg = `Error: ${err.message || 'Unknown network issue'}`;
        }
        addNotification(errorMsg, 'error');
        setSupporters(prev => prev.map(s => s.id === supporterId ? { ...s, isAvailable: false } : s));
      }
    } else {
      setSupporters(prev => prev.map(s => s.id === supporterId ? { ...s, isAvailable: newState } : s));
      if (user?.id === supporterId && newState === false) {
        voiceService.destroy();
        addNotification("System Offline.", 'info');
      }
    }
  };

  const connectToFirstAvailable = (): ConnectResult => {
    // 1. Check credits
    if (user && !user.isSubscriber && user.credits <= 0) {
        return 'NO_CREDITS';
    }

    // 2. Find online mentor (who isn't the user themselves)
    const availableMentor = supporters.find(s => s.isAvailable && s.id !== user?.id);

    if (availableMentor) {
        setCurrentConnectedSupporter(availableMentor);
        return 'CONNECTED';
    }

    return 'NO_MENTORS';
  };

  const addShift = (sid: string, d: string, t: string) => {
    setSupporters(prev => prev.map(s => {
      if (s.id === sid) {
        return { ...s, shifts: [...(s.shifts || []), { id: crypto.randomUUID(), day: d, time: t }] };
      }
      return s;
    }));
    addNotification(`Shift added for ${d}`, 'success');
  };

  const removeShift = (sid: string, shid: string) => {
    setSupporters(prev => prev.map(s => {
      if (s.id === sid) {
        return { ...s, shifts: (s.shifts || []).filter(sh => sh.id !== shid) };
      }
      return s;
    }));
    addNotification("Shift removed.", 'info');
  };

  const login = async (role: UserRole) => {
    const userId = role === UserRole.CALLER ? 'c_me' : 's_me';
    const userName = role === UserRole.CALLER ? 'Beta Tester' : 'Magdalene';
    // Ensure beta tester has credits to test
    setUser({ id: userId, name: userName, role, credits: 10, isSubscriber: false, hasHadHumanDesign: false });
  };

  const logout = () => { 
    setUser(null); 
    setActiveCallState(CallState.IDLE); 
    voiceService.destroy(); 
  };
  
  const purchaseCredit = () => {};
  const donateToBank = () => {};
  const subscribe = () => {};
  const useCredit = () => true;
  const scheduleAppointment = () => {};
  const requestCallback = async () => {};
  const supporterCashOut = () => addNotification("Payout requested ($120). Processing...", 'success');
  const createOpenShift = () => {};
  const claimShift = () => {};
  const blockCaller = () => {};
  const saveCallerNote = () => {};
  const getCallerNotes = async () => [];
  const setJustPaidForHumanDesign = (val: boolean) => setJustPaidForHumanDesignState(val);
  const updateApplicationStatus = async () => {};
  const submitApplication = () => {};
  const removeNotification = (id: string) => setNotifications(p => p.filter(n => n.id !== id));

  return (
    <AppContext.Provider value={{
      user, supporters, openShifts, mentorApplications, notifications, removeNotification, callBankBalance, login, logout,
      donateToBank, purchaseCredit, subscribe, useCredit, activeCallState, setActiveCallState, appointments, scheduleAppointment,
      toggleSupporterAvailability, connectToFirstAvailable, supporterCashOut, addShift, removeShift, createOpenShift, claimShift,
      blockCaller, currentConnectedSupporter, saveCallerNote, getCallerNotes, applicationState, setApplicationState, submitApplication,
      updateApplicationStatus, affiliateResources, justPaidForHumanDesign, setJustPaidForHumanDesign, requestCallback
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
