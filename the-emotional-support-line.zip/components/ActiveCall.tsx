import React, { useEffect, useState, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import { CALL_DURATION_SECONDS, WARNING_TIME_SECONDS, COST_PER_CALL, HUMAN_DESIGN_COST, SUBSCRIPTION_COST } from '../constants';
import { voiceService } from '../services/geminiLiveService'; // Actually voiceService now
import { CallState, UserRole, AffiliateResource } from '../types';
import { PaymentModal } from './PaymentModal';

export const ActiveCall = () => {
  const { setActiveCallState, user, useCredit, blockCaller, activeCallState, currentConnectedSupporter, affiliateResources } = useApp();
  const [timeLeft, setTimeLeft] = useState(CALL_DURATION_SECONDS);
  const [isWarningActive, setIsWarningActive] = useState(false);
  const [showExtendModal, setShowExtendModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState<'EXTEND' | 'HUMAN_DESIGN' | 'SUBSCRIPTION' | 'DONATION' | null>(null);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [showDndHint, setShowDndHint] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState<'CONNECTING' | 'CONNECTED'>('CONNECTING');
  
  // Post Call State
  const [supporterNote, setSupporterNote] = useState('Just had a powerful connection on The Emotional Support Line. Grateful to be able to mentor today. #ESL #IntuitiveMentoring');
  
  // Upsell Logic
  const getPrimaryUpsell = (): 'SUBSCRIPTION' | 'HUMAN_DESIGN' | 'DONATION' => {
      if (!user?.isSubscriber) return 'SUBSCRIPTION';
      if (!user?.hasHadHumanDesign) return 'HUMAN_DESIGN';
      return 'DONATION';
  };

  const primaryUpsellType = getPrimaryUpsell();

  useEffect(() => {
    // Hide DND hint after 8 seconds
    const timer = setTimeout(() => setShowDndHint(false), 8000);
    return () => clearTimeout(timer);
  }, []);

  // Initialize Call Simulation
  useEffect(() => {
    if (activeCallState !== CallState.ACTIVE) return;
    let mounted = true;

    const startCall = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // Supporter Logic
        if (user?.role === UserRole.SUPPORTER) {
             // If supporter answered an incoming call, the service is already active.
             if (voiceService.isActive()) {
                 console.log("Supporter joined active call");
                 setConnectionStatus('CONNECTED');
             } else {
                 // Fallback if they navigated here manually (shouldn't happen often)
                 await voiceService.initialize(user.id);
             }
        } 
        // Caller Logic
        else {
             // Use the ID of the selected supporter, fallback to 's_me' (Admin) if null
             const targetId = currentConnectedSupporter?.id || 's_me'; 
             console.log("Caller connecting to:", targetId);
             await voiceService.connect(targetId);
             if (mounted) setConnectionStatus('CONNECTED');
        }
      } catch (err) {
        console.error("Failed to start call", err);
        alert("Microphone access is required for the call.");
        setActiveCallState(CallState.IDLE);
      }
    };
    
    startCall();
    
    return () => {
      mounted = false;
      // We only disconnect if we are the caller. 
      // Supporters might want to stay online. 
      // But for this component unmount (End Call), we generally want to hang up.
      voiceService.disconnect();
    };
  }, [activeCallState, user, currentConnectedSupporter]);

  // Timer Logic
  useEffect(() => {
    if (activeCallState !== CallState.ACTIVE || connectionStatus !== 'CONNECTED') return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        const newVal = prev - 1;
        if (newVal === WARNING_TIME_SECONDS && !isWarningActive) {
           setIsWarningActive(true);
           if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
        }
        if (newVal <= 0) {
            clearInterval(timer);
            handleTimeUp();
            return 0;
        }
        return newVal;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isWarningActive, activeCallState, connectionStatus]);

  const handleTimeUp = () => setShowExtendModal(true);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => setActiveCallState(CallState.POST_CALL);
  const handleFinalExit = () => setActiveCallState(CallState.IDLE);

  const onExtensionPaymentSuccess = () => {
     setTimeLeft(CALL_DURATION_SECONDS);
     setShowExtendModal(false);
     setShowPaymentModal(null);
     setIsWarningActive(false);
  };

  const handleBlockAction = (reason: 'personal' | 'sexual' | 'abusive') => {
      blockCaller('c_mock', reason);
      setShowBlockModal(false);
      if (reason === 'sexual' || reason === 'abusive') {
        setActiveCallState(CallState.IDLE);
      } else {
        setActiveCallState(CallState.POST_CALL);
      }
  };

  // --- RENDER: POST CALL SUMMARY ---
  if (activeCallState === CallState.POST_CALL) {
      return (
        <div className="fixed inset-0 z-40 bg-brand-bg flex flex-col items-center justify-center p-6 animate-in fade-in overflow-y-auto">
           <div className="max-w-md w-full text-center space-y-6">
              <div className="w-16 h-16 bg-dragonfly/10 rounded-full flex items-center justify-center mx-auto text-dragonfly">
                  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
              </div>
              <h2 className="text-3xl font-bold text-elegance">Call Ended</h2>
              {user?.role === UserRole.SUPPORTER ? (
                  <div className="space-y-6">
                      <p className="text-coney">How was the connection? Share an anonymous reflection.</p>
                      <textarea
                        className="w-full p-4 border border-buff rounded-xl text-elegance focus:ring-2 focus:ring-dragonfly outline-none resize-none bg-buff/5"
                        rows={3}
                        value={supporterNote}
                        onChange={(e) => setSupporterNote(e.target.value)}
                        placeholder="Share a thought..."
                      />
                      <button onClick={handleFinalExit} className="w-full py-3 bg-coney text-white rounded-xl font-medium hover:bg-elegance">Return to Dashboard</button>
                  </div>
              ) : (
                  <div className="space-y-6">
                      <p className="text-coney">Thank you for connecting with {currentConnectedSupporter?.name || 'the Mentor'}.</p>
                      <div className="bg-buff/10 p-6 rounded-2xl border border-buff/30">
                          <p className="text-elegance font-bold mb-2">We hope you feel lighter.</p>
                          <p className="text-sm text-coney">Take a moment to breathe and integrate this session.</p>
                      </div>
                      <button onClick={handleFinalExit} className="w-full py-3 bg-elegance text-white rounded-xl font-medium hover:bg-coney">Return to Dashboard</button>
                  </div>
              )}
           </div>
        </div>
      );
  }

  // --- RENDER: ACTIVE CALL ---
  return (
    <div className="fixed inset-0 z-40 bg-elegance flex flex-col items-center justify-center text-white overflow-hidden">
      {showDndHint && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-md text-white px-6 py-3 rounded-full text-sm z-50 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 w-[90%] md:w-auto justify-center shadow-lg border border-white/10">
            <span className="flex-1 text-center md:text-left">🌙 For privacy, please enable <b>Do Not Disturb</b> on your device.</span>
            <button onClick={() => setShowDndHint(false)} className="opacity-70 hover:opacity-100 p-1">✕</button>
        </div>
      )}

      {/* Visualizer Background */}
      <div className="absolute inset-0 opacity-40 bg-gradient-to-br from-elegance to-coney">
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-dragonfly blur-3xl transition-all duration-1000 ${connectionStatus === 'CONNECTED' ? 'animate-pulse w-64 h-64' : 'w-32 h-32'}`} />
      </div>

      <div className="relative z-10 w-full max-w-lg px-4 flex flex-col h-full py-6">
        
        {/* Main Call Info - Flexible Height */}
        <div className="flex-1 flex flex-col items-center justify-center space-y-8">
            <div className="space-y-4 text-center">
                {connectionStatus === 'CONNECTING' ? (
                    <div className="flex flex-col items-center gap-4">
                        <div className="w-20 h-20 rounded-full border-4 border-tiki border-t-transparent animate-spin"></div>
                        <h2 className="text-2xl font-light tracking-wide text-buff">Connecting Secure Line...</h2>
                        <p className="text-coney text-sm">Please wait while we connect you to {currentConnectedSupporter?.name || 'Magdalene'}.</p>
                    </div>
                ) : (
                    <>
                        <div className="w-24 h-24 bg-white/10 rounded-full mx-auto flex items-center justify-center border border-white/20 shadow-[0_0_30px_rgba(255,255,255,0.1)]">
                            <svg className="w-10 h-10 text-buff" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9v-2h2v2zm0-4H9V7h2v5z" /></svg>
                        </div>
                        <h2 className="text-3xl font-light tracking-wide text-buff">
                            {user?.role === UserRole.SUPPORTER ? 'On Call' : 'Connected'}
                        </h2>
                        <p className="text-coney text-sm">
                            {user?.role === UserRole.SUPPORTER ? 'Mentoring...' : `Talking with ${currentConnectedSupporter?.name || 'Magdalene'}`}
                        </p>
                        <div className="text-8xl font-mono font-bold tracking-tighter text-buff drop-shadow-lg mt-4">
                            {formatTime(timeLeft)}
                        </div>
                    </>
                )}
            </div>
        </div>
        
        {timeLeft < WARNING_TIME_SECONDS && timeLeft > 0 && connectionStatus === 'CONNECTED' && (
             <div className="animate-in slide-in-from-bottom-10 fade-in duration-500 bg-white/10 backdrop-blur-md text-white p-4 rounded-xl border border-white/20 max-w-sm mx-auto shadow-2xl mt-4">
                 <div className="flex items-center gap-3 mb-3">
                     <span className="animate-pulse w-2 h-2 rounded-full bg-tiki"></span>
                     <p className="font-bold text-sm">5 Minutes Remaining</p>
                 </div>
                 
                 {/* Smart Upsell Warning */}
                 <div className="flex flex-col gap-2">
                     <button 
                        onClick={() => setShowPaymentModal(primaryUpsellType)}
                        className="w-full bg-tiki text-white text-xs font-bold py-3 rounded-lg hover:bg-[#b05a3b] transition-colors shadow-lg shadow-tiki/20 border border-tiki"
                    >
                        {primaryUpsellType === 'SUBSCRIPTION' && `Tackle this phase: Upgrade to Unlimited ($${SUBSCRIPTION_COST}/mo)`}
                        {primaryUpsellType === 'HUMAN_DESIGN' && `Go Deeper: Book Human Design Reading ($${HUMAN_DESIGN_COST})`}
                        {primaryUpsellType === 'DONATION' && `Pay it forward: Donate a call to someone in need`}
                    </button>
                    {!user?.isSubscriber && (
                        <button 
                            onClick={() => setShowPaymentModal('EXTEND')}
                            className="w-full bg-white/10 text-white text-xs font-medium py-2 rounded-lg hover:bg-white/20 transition-colors"
                        >
                            Extend this call 30 mins (${COST_PER_CALL})
                        </button>
                    )}
                </div>
             </div>
        )}

        <div className="flex justify-center gap-6 mt-6 shrink-0 pb-4">
            <button 
                onClick={handleEndCall}
                className="bg-red-500 hover:bg-red-600 text-white p-6 rounded-full shadow-xl transition-transform hover:scale-105"
                title="End Call"
            >
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            
            {user?.role === UserRole.SUPPORTER && connectionStatus === 'CONNECTED' && (
                 <button 
                    onClick={() => setShowBlockModal(true)}
                    className="bg-elegance border border-buff text-buff p-6 rounded-full shadow-xl transition-transform hover:scale-105"
                    title="Block User"
                >
                    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                 </button>
            )}
        </div>
      </div>

      {showPaymentModal && (
          <PaymentModal 
              type={showPaymentModal} 
              onClose={() => setShowPaymentModal(null)} 
              onSuccess={onExtensionPaymentSuccess} 
          />
      )}
      
      {showExtendModal && !showPaymentModal && (
          <div className="absolute inset-0 bg-elegance/95 flex items-center justify-center z-50 p-4">
               <div className="bg-white text-elegance p-8 rounded-2xl max-w-md w-full shadow-2xl animate-in fade-in zoom-in border-4 border-buff">
                  <h3 className="text-2xl font-bold mb-4">Time is Up</h3>
                  <p className="mb-6 text-coney">
                      {user?.isSubscriber 
                        ? "You have reached the end of today's session." 
                        : "You are doing the work. Don't stop now."}
                  </p>
                  
                  <div className="flex flex-col gap-4">
                        {/* Primary Action (Smart Context) */}
                        <div className="bg-buff/10 p-4 rounded-xl border border-buff border-dashed">
                             <p className="text-xs font-bold text-tiki uppercase mb-1">
                                {primaryUpsellType === 'DONATION' ? 'Good Karma' : 'Recommended'}
                             </p>
                             <p className="text-sm text-coney mb-3">
                                {primaryUpsellType === 'SUBSCRIPTION' && "Tackle this phase completely with daily support."}
                                {primaryUpsellType === 'HUMAN_DESIGN' && "You are ready for the next level. Understand your blueprint."}
                                {primaryUpsellType === 'DONATION' && "You are in a good place. Help someone else get there."}
                             </p>
                             <button onClick={() => setShowPaymentModal(primaryUpsellType)} className="w-full py-3 bg-tiki text-white rounded-xl font-bold hover:bg-[#b05a3b] shadow-lg">
                                {primaryUpsellType === 'SUBSCRIPTION' && `Upgrade to Unlimited ($${SUBSCRIPTION_COST}/mo)`}
                                {primaryUpsellType === 'HUMAN_DESIGN' && `Book Human Design ($${HUMAN_DESIGN_COST})`}
                                {primaryUpsellType === 'DONATION' && `Donate a Call ($25)`}
                             </button>
                        </div>

                         {/* Secondary Action: Extend (Only for non-subscribers typically, but we allow extensions for pay-per-call) */}
                         {!user?.isSubscriber && (
                             <button onClick={() => setShowPaymentModal('EXTEND')} className="w-full py-3 bg-dragonfly text-white rounded-xl font-medium hover:bg-[#607d7a]">
                                Just extend this session 30m (${COST_PER_CALL})
                             </button>
                         )}
                         
                         <button onClick={handleEndCall} className="w-full py-3 border border-coney/30 text-coney rounded-xl font-medium hover:bg-buff/20">End Call Now</button>
                  </div>
               </div>
          </div>
      )}

      {showBlockModal && (
          <div className="absolute inset-0 bg-elegance/95 flex items-center justify-center z-50 p-4">
              <div className="bg-white text-elegance p-6 rounded-2xl max-w-sm w-full shadow-2xl border-2 border-red-300">
                  <h3 className="text-xl font-bold mb-4 text-red-600">Block Caller</h3>
                  <p className="mb-4 text-sm text-coney">Select a reason to end the call and block this user.</p>
                  <div className="space-y-3">
                      <button onClick={() => handleBlockAction('personal')} className="w-full py-3 bg-slate-100 text-elegance rounded-lg font-medium hover:bg-slate-200">Just not a good fit (Block for me)</button>
                      <div className="border-t border-red-100 pt-2 mt-2">
                        <p className="text-[10px] text-red-600 font-bold uppercase mb-1">Zero Tolerance Policy</p>
                        <button onClick={() => handleBlockAction('sexual')} className="w-full py-3 bg-red-100 text-red-800 rounded-lg font-bold hover:bg-red-200 border border-red-200 mb-2">Sexual Harassment</button>
                        <button onClick={() => handleBlockAction('abusive')} className="w-full py-3 bg-orange-100 text-orange-800 rounded-lg font-medium hover:bg-orange-200">Threats / Abuse</button>
                      </div>
                      <button onClick={() => setShowBlockModal(false)} className="w-full py-2 text-coney text-sm hover:underline mt-2">Cancel</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};