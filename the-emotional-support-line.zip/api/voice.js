
const twilio = require('twilio');
const qs = require('querystring');

module.exports = (request, response) => {
  const VoiceResponse = twilio.twiml.VoiceResponse;
  let twiml = new VoiceResponse();

  try {
      // 1. ROBUST BODY PARSING
      // Twilio sends data as 'application/x-www-form-urlencoded'.
      // Vercel sometimes parses this automatically, but sometimes passes it as a string/buffer.
      let body = request.body || {};

      if (Buffer.isBuffer(body)) {
          body = qs.parse(body.toString());
      } else if (typeof body === 'string') {
          // Try parsing as JSON, fallback to Query String
          try {
              body = JSON.parse(body);
          } catch (e) {
              body = qs.parse(body);
          }
      }

      const query = request.query || {};
      
      // Merge for easy access
      const params = { ...query, ...body };

      const to = params.To;
      const from = params.From;
      const digits = params.Digits;
      const paymentResult = params.Result; 
      const step = query.step; // Keep step in query to persist state across TwiML actions

      console.log(`[Voice] Incoming: From=${from}, To=${to}, Step=${step}`);

      const adminPhone = process.env.ADMIN_PHONE || '+19704437052';

      // HELPER: Dial Logic
      const dialMentor = (responseNode, targetIdentity = 's_me') => {
          const dial = responseNode.dial({ timeout: 30 });
          // Ring the App (Browser)
          dial.client(targetIdentity);
          
          // Ring the Phone (Forwarding) - ONLY if calling the admin ('s_me')
          // We assume other supporters only use the app.
          if (targetIdentity === 's_me' && adminPhone && adminPhone.startsWith('+')) {
              dial.number(adminPhone);
          }
      };

      // ============================================================
      // LOGIC FLOW
      // ============================================================

      // CASE 1: PAYMENT CALLBACK
      if (step === 'process_payment') {
          if (paymentResult === 'success') {
              twiml.say("Payment authorized. Connecting you to a Mentor now.");
              dialMentor(twiml, 's_me'); // Default to Admin for now if random payment
          } else {
              twiml.say("The payment could not be processed. Please try again.");
              twiml.redirect('/api/voice'); // Loop back to main menu
          }
      }

      // CASE 2: MENU SELECTION
      else if (step === 'process_gather') {
          if (digits === '1') {
              twiml.say("Please enter your payment information.");
              // REQUIRED: 'Stripe_Connector' must exist in Twilio Console > Voice > Pay Connectors
              twiml.pay({
                  paymentConnector: 'Stripe_Connector', 
                  action: '/api/voice?step=process_payment',
                  chargeAmount: '45.00',
                  currency: 'usd',
                  description: 'Emotional Support Session'
              });
          } else {
              // Press 2 or other -> Connect existing user to Admin
              twiml.say("Connecting you now.");
              dialMentor(twiml, 's_me');
          }
      }

      // CASE 3: INBOUND CALL (PSTN)
      // If 'From' starts with '+' it's a real phone, not the web app
      else if (from && from.startsWith('+')) {
          const gather = twiml.gather({
              numDigits: 1,
              action: '/api/voice?step=process_gather',
              timeout: 10
          });
          
          gather.say("Welcome to the Emotional Support Line.");
          gather.say("To start a session for forty-five dollars, press 1.");
          gather.say("If you have existing credits, press 2.");

          // If they don't press anything, loop
          twiml.redirect('/api/voice');
      } 

      // CASE 4: OUTBOUND APP CALL (Browser calling Mentor)
      else if (to && to.startsWith('s_')) {
          const dial = twiml.dial({
              timeout: 30, 
              callerId: process.env.TWILIO_PHONE_NUMBER 
          });
          
          // Use the specific 'to' identity requested by the app
          console.log(`Dialing specific supporter: ${to}`);
          dial.client(to);
          
          // Optional: Forwarding if it's the admin
          if (to === 's_me' && adminPhone) {
             dial.number(adminPhone);
          }
      }
      
      // CASE 5: FALLBACK
      else {
          console.warn("Unknown call flow:", params);
          twiml.say("We could not connect your call. Please check the number.");
      }

  } catch (error) {
      console.error("Critical Voice Error:", error);
      // Reset TwiML to ensure valid XML response even on error
      twiml = new VoiceResponse();
      twiml.say("A system error occurred. Please try again later.");
  }

  response.setHeader('Content-Type', 'text/xml');
  response.status(200).send(twiml.toString());
};
