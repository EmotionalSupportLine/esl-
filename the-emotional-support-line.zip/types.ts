
export enum UserRole {
  CALLER = 'CALLER',
  SUPPORTER = 'SUPPORTER',
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  credits: number; // Number of calls available
  isSubscriber: boolean;
  subscriptionEndDate?: string;
  hasHadHumanDesign: boolean;
  isBanned?: boolean;
  bio?: string; // CRM bio info
}

export interface Shift {
    id: string;
    day: string; // e.g., "Monday"
    time: string; // e.g., "10:00 AM - 2:00 PM"
}

export interface OpenShift {
    id: string;
    day: string;
    time: string;
    isClaimed: boolean;
    claimedBy?: string; // Supporter Name
}

export interface Supporter {
  id: string;
  name: string;
  bio: string;
  isAvailable: boolean;
  tags: string[];
  earnings: number;
  avatar?: string;
  shifts: Shift[];
  blockedCallerIds: string[]; // Personal blocks
  calendarUrl?: string;
}

export interface Appointment {
  id: string;
  supporterId: string;
  callerId: string;
  time: string;
  status: 'pending' | 'confirmed' | 'completed';
  callBackNumber?: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'error';
}

export interface CallerNote {
    id: string;
    callerId: string;
    mentorId: string;
    text: string;
    date: string;
}

export interface AffiliateResource {
    id: string;
    keywords: string[];
    label: string;
    text: string;
    url: string;
}

export enum CallState {
  IDLE = 'IDLE',
  CONNECTING = 'CONNECTING',
  ACTIVE = 'ACTIVE',
  PAUSED_FOR_PAYMENT = 'PAUSED_FOR_PAYMENT',
  POST_CALL = 'POST_CALL',
  ENDED = 'ENDED'
}

export enum ApplicationState {
    NONE = 'NONE',
    VIEWING = 'VIEWING',
    SUBMITTED = 'SUBMITTED'
}

export interface MentorApplication {
    id?: string;
    legalName: string;
    mentorName: string; // Pseudonym
    email: string;
    phone: string;
    experience: string;
    ethicsStatement: string;
    crisisHandling: string;
    communicationStyle: string;
    
    // Extended Fields for 5-Step App
    expertise: string[];
    bio: string; 
    avatarStyle: string;
    
    agreedToNDA: boolean;
    status?: 'PENDING' | 'APPROVED' | 'REJECTED';
    date?: string;
}

export type ConnectResult = 'CONNECTED' | 'NO_MENTORS' | 'NO_CREDITS';
