const twilio = require('twilio');

module.exports = (request, response) => {
  const MessagingResponse = twilio.twiml.MessagingResponse;
  const twiml = new MessagingResponse();

  // Auto-reply to ANY incoming text
  twiml.message("Automated Reply: This line is for Voice Calls and Scheduling Notifications only. We do not monitor incoming texts. To speak with an Intuitive Mentor, please call this number directly or visit www.theemotionalsupportline.com.");

  response.setHeader('Content-Type', 'text/xml');
  response.status(200).send(twiml.toString());
};