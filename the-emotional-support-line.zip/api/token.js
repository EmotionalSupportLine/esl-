
const twilio = require('twilio');

module.exports = (request, response) => {
  const AccessToken = twilio.jwt.AccessToken;
  const VoiceGrant = AccessToken.VoiceGrant;

  const identity = request.query.identity || 'unknown_user';

  const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID;
  const twilioApiKey = process.env.TWILIO_API_KEY;
  const twilioApiSecret = process.env.TWILIO_API_SECRET;
  const outgoingApplicationSid = process.env.TWILIO_TWIML_APP_SID;

  // Debug check
  const missing = [];
  if (!twilioAccountSid) missing.push('TWILIO_ACCOUNT_SID');
  if (!twilioApiKey) missing.push('TWILIO_API_KEY');
  if (!twilioApiSecret) missing.push('TWILIO_API_SECRET');
  if (!outgoingApplicationSid) missing.push('TWILIO_TWIML_APP_SID');

  if (missing.length > 0) {
      return response.status(500).json({ 
        error: `Missing Environment Variables: ${missing.join(', ')}`,
        note: "Ensure these are added in your Vercel Project Settings."
      });
  }

  try {
    const token = new AccessToken(
      twilioAccountSid,
      twilioApiKey,
      twilioApiSecret,
      { identity: identity, ttl: 3600 }
    );

    const voiceGrant = new VoiceGrant({
      outgoingApplicationSid: outgoingApplicationSid,
      incomingAllow: true, 
    });

    token.addGrant(voiceGrant);

    response.status(200).json({ 
        token: token.toJwt(),
        identity: identity
    });
  } catch (err) {
    console.error("Token Generation Error:", err);
    response.status(500).json({ error: "Failed to generate access token. Check API Key/Secret." });
  }
};
