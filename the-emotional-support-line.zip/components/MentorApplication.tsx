
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { MentorApplication, ApplicationState } from '../types';

const EXPERTISE_TAGS = [
    // Mental & Emotional Health
    "Anxiety", "Panic Attacks", "Overwhelm", "Overthinking", "Burnout", 
    "Stress", "Work Stress", "Emotional Well Being", "Mental Well Being",
    "Nervous System Regulation", "Insomnia", "Agoraphobia", "Isolation",
    "PTSD", "ICU PTSD", "Grief", "Recovery", "Addiction Recovery",
    
    // Relationships & Life
    "Dating", "Marriage", "Divorce", "Relationship Recovery", "Codependence", 
    "Parenting", "Infertility", "Family Dynamics",
    
    // Spiritual & Purpose
    "Soul Purpose", "Meaning of Life", "Spirituality", "Christianity", 
    "Witchy Vibes", "Woo Woo", "Human Design", "Energy Work",
    
    // Modalities & Tools
    "Internal Family Systems", "EMDR", "Tapping/EFT", "Mindfulness and Meditation", 
    "Stress Management Techniques", "Self Care Activities",
    
    // Specific Challenges
    "Chronic Illness", "Food Addiction", "Food Issues", "Financial", 
    "Debt", "Business", "Career Blocks"
];

export const MentorApplicationForm = () => {
    const { setApplicationState, submitApplication } = useApp();
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState<MentorApplication>({
        legalName: '',
        mentorName: '',
        email: '',
        phone: '',
        experience: '',
        ethicsStatement: '',
        crisisHandling: '',
        communicationStyle: '',
        expertise: [],
        bio: '',
        avatarStyle: '',
        agreedToNDA: false
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const toggleExpertise = (tag: string) => {
        setFormData(prev => ({
            ...prev,
            expertise: prev.expertise.includes(tag) 
                ? prev.expertise.filter(t => t !== tag)
                : [...prev.expertise, tag]
        }));
    };

    const generateBioDraft = () => {
        const traits = formData.communicationStyle || "supportive";
        // Simple cleanup
        const cleanTraits = traits.length > 50 ? "insightful" : traits;
        
        const topTags = formData.expertise.length > 0 
            ? formData.expertise.slice(0, 3).join(", ") 
            : "emotional wellness";

        const bio = `Meet ${formData.mentorName}, an Intuitive Mentor known for their ${cleanTraits.toLowerCase()} approach. Specializing in ${topTags}, they create a safe container for deep processing. Whether you are navigating ${formData.expertise[3] || "life's challenges"} or seeking a reality check, ${formData.mentorName} brings grounded wisdom and authentic connection to every call.`;
        setFormData(prev => ({ ...prev, bio }));
    };

    const handleNext = (e: React.FormEvent) => {
        e.preventDefault();
        setStep(prev => prev + 1);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.agreedToNDA) {
            submitApplication(formData);
        } else {
            alert("You must agree to the contract to submit.");
        }
    };

    return (
        <div className="max-w-2xl mx-auto bg-brand-bg p-8 rounded-3xl shadow-xl border border-buff animate-in slide-in-from-bottom-4">
            <div className="flex justify-between items-center mb-8 border-b border-buff/30 pb-4">
                <h2 className="text-2xl font-bold text-elegance">Mentor Application</h2>
                <button onClick={() => setApplicationState(ApplicationState.NONE)} className="text-coney hover:text-dragonfly">✕ Close</button>
            </div>

            {/* Progress Bar */}
            <div className="flex gap-2 mb-8">
                {[1, 2, 3, 4, 5].map(s => (
                    <div key={s} className={`h-2 flex-1 rounded-full ${step >= s ? 'bg-dragonfly' : 'bg-gray-200'}`}></div>
                ))}
            </div>

            <form onSubmit={step === 5 ? handleSubmit : handleNext}>
                
                {/* STEP 1: IDENTITY */}
                {step === 1 && (
                    <div className="space-y-6">
                        <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-sm text-blue-800">
                            <strong>Safety First:</strong> We prioritize your anonymity. Your "Mentor Name" is the only name callers will see.
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-bold text-coney mb-1">Legal Name</label>
                                <input name="legalName" required value={formData.legalName} onChange={handleChange} className="w-full p-3 border border-buff rounded-xl" placeholder="Jane Doe" />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-dragonfly mb-1">Mentor Name (Pseudonym)</label>
                                <input name="mentorName" required value={formData.mentorName} onChange={handleChange} className="w-full p-3 border border-dragonfly rounded-xl bg-dragonfly/5" placeholder="e.g. Starfinder" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-bold text-coney mb-1">Email</label>
                                <input name="email" type="email" required value={formData.email} onChange={handleChange} className="w-full p-3 border border-buff rounded-xl" />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-coney mb-1">Phone</label>
                                <input name="phone" type="tel" required value={formData.phone} onChange={handleChange} className="w-full p-3 border border-buff rounded-xl" />
                            </div>
                        </div>
                    </div>
                )}

                {/* STEP 2: QUALIFICATIONS */}
                {step === 2 && (
                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-bold text-coney mb-1">Why do you want to be an Intuitive Mentor?</label>
                            <textarea name="experience" required value={formData.experience} onChange={handleChange} rows={3} className="w-full p-3 border border-buff rounded-xl" placeholder="Share your background and motivation..." />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-coney mb-1">Communication Style (Adjectives)</label>
                            <input name="communicationStyle" required value={formData.communicationStyle} onChange={handleChange} className="w-full p-3 border border-buff rounded-xl" placeholder="e.g., Direct, Gentle, Curious, Warm" />
                            <p className="text-[10px] text-coney mt-1">Please list 3-4 adjectives. Do not write full sentences.</p>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-coney mb-1">How would you handle a caller in crisis (988)?</label>
                            <textarea name="crisisHandling" required value={formData.crisisHandling} onChange={handleChange} rows={2} className="w-full p-3 border border-buff rounded-xl" placeholder="We are not a crisis line. How do you redirect?" />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-coney mb-1">Statement of Ethics</label>
                            <textarea name="ethicsStatement" required value={formData.ethicsStatement} onChange={handleChange} rows={2} className="w-full p-3 border border-buff rounded-xl" placeholder="Briefly describe your ethical boundaries..." />
                        </div>
                    </div>
                )}

                {/* STEP 3: EXPERTISE TAGS */}
                {step === 3 && (
                    <div className="space-y-6">
                        <h3 className="font-bold text-lg text-elegance">Areas of Expertise</h3>
                        <p className="text-sm text-coney">Select topics you specialize in (Good for matching & SEO).</p>
                        
                        <div className="flex flex-wrap gap-2 max-h-60 overflow-y-auto p-2 border border-buff/30 rounded-xl scrollbar-thin">
                            {EXPERTISE_TAGS.map(tag => (
                                <button
                                    key={tag}
                                    type="button"
                                    onClick={() => toggleExpertise(tag)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                                        formData.expertise.includes(tag) 
                                        ? 'bg-dragonfly text-white shadow-md' 
                                        : 'bg-gray-100 text-coney hover:bg-gray-200'
                                    }`}
                                >
                                    {tag}
                                </button>
                            ))}
                        </div>
                        <p className="text-xs text-coney italic">Selected: {formData.expertise.join(", ")}</p>
                    </div>
                )}

                {/* STEP 4: BIO EDITOR */}
                {step === 4 && (
                    <div className="space-y-6">
                        <h3 className="font-bold text-lg text-elegance">Your Public Bio</h3>
                        <p className="text-sm text-coney">Click "Auto-Generate" to create a draft, then edit it to make it yours.</p>

                        <div className="bg-buff/10 p-4 rounded-xl border border-buff/30">
                            <div className="flex justify-end mb-2">
                                <button 
                                    type="button" 
                                    onClick={generateBioDraft}
                                    className="text-xs bg-white border border-dragonfly text-dragonfly px-3 py-1 rounded-full hover:bg-dragonfly hover:text-white transition-colors"
                                >
                                    ✨ Auto-Generate Draft
                                </button>
                            </div>
                            <textarea 
                                name="bio" 
                                required 
                                value={formData.bio} 
                                onChange={handleChange} 
                                rows={6} 
                                className="w-full p-3 border border-buff rounded-xl text-sm" 
                                placeholder="Click Auto-Generate..." 
                            />
                        </div>
                    </div>
                )}

                {/* STEP 5: CONTRACT */}
                {step === 5 && (
                    <div className="space-y-6">
                        <h3 className="font-bold text-lg text-elegance">Independent Contractor Agreement & NDA</h3>
                        <div className="h-48 overflow-y-scroll border border-coney/20 p-4 rounded-xl text-xs text-coney bg-gray-50 leading-relaxed">
                            <p className="font-bold mb-2">AGREEMENT BETWEEN: The Emotional Support Line LLC ("Company") AND {formData.legalName} ("Contractor")</p>
                            <p className="mb-2"><strong>1. PROPRIETARY INFORMATION.</strong> Contractor agrees that all Caller Data is the sole property of the Company.</p>
                            <p className="mb-2"><strong>2. INDEPENDENT CONTRACTOR.</strong> Contractor is an independent agent, not an employee.</p>
                            <p className="mb-2"><strong>3. SAFETY & CONDUCT.</strong> Contractor agrees to use the provided Pseudonym "{formData.mentorName}".</p>
                            <p className="mb-2"><strong>4. BIO AUTHORIZATION.</strong> Contractor authorizes Company to use the submitted bio.</p>
                        </div>
                        
                        <div className="flex items-start gap-3 p-4 bg-buff/10 rounded-xl border border-buff">
                            <input 
                                type="checkbox" 
                                id="nda" 
                                checked={formData.agreedToNDA} 
                                onChange={(e) => setFormData({...formData, agreedToNDA: e.target.checked})}
                                className="mt-1 w-5 h-5 text-dragonfly rounded focus:ring-dragonfly"
                            />
                            <label htmlFor="nda" className="text-sm text-elegance">
                                I, <strong>{formData.legalName}</strong>, agree to the terms above (Digital Signature).
                            </label>
                        </div>
                    </div>
                )}

                <div className="mt-8 flex gap-4">
                    {step > 1 && (
                        <button type="button" onClick={() => setStep(prev => prev - 1)} className="px-6 py-3 border border-coney rounded-xl text-coney font-medium hover:bg-gray-50">Back</button>
                    )}
                    <button type="submit" className="flex-1 py-3 bg-dragonfly text-white rounded-xl font-bold hover:bg-[#607d7a] shadow-lg">
                        {step === 5 ? 'Sign & Submit' : 'Next Step'}
                    </button>
                </div>
            </form>
        </div>
    );
};
