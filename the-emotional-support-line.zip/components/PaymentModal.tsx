
import React, { useState } from 'react';
import { COST_PER_CALL, SUBSCRIPTION_COST, HUMAN_DESIGN_COST, STRIPE_LINKS } from '../constants';

interface PaymentModalProps {
  onClose: () => void;
  onSuccess?: () => void;
  type: 'CREDIT' | 'SUBSCRIPTION' | 'DONATION' | 'EXTEND' | 'HUMAN_DESIGN';
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ onClose, onSuccess, type }) => {
  const [processing, setProcessing] = useState(false);

  const handlePayment = () => {
    setProcessing(true);
    
    // Redirect to Stripe
    let link = '';
    
    // In a real app, you would pass the UserID as a URL parameter to Stripe
    // e.g. ?client_reference_id=user_123
    
    switch (type) {
        case 'CREDIT':
            link = `${STRIPE_LINKS.SINGLE_CALL}?client_reference_id=demo_user&success_url=${window.location.origin}?payment_success=single`;
            break;
        case 'EXTEND':
             // Assuming same cost as single call for MVP
            link = `${STRIPE_LINKS.SINGLE_CALL}?client_reference_id=demo_user&success_url=${window.location.origin}?payment_success=single`;
            break;
        case 'SUBSCRIPTION':
            link = `${STRIPE_LINKS.SUBSCRIPTION}?client_reference_id=demo_user&success_url=${window.location.origin}?payment_success=subscription`;
            break;
        case 'DONATION':
            link = `${STRIPE_LINKS.DONATION}?client_reference_id=demo_user&success_url=${window.location.origin}?payment_success=donation`;
            break;
        case 'HUMAN_DESIGN':
            link = `${STRIPE_LINKS.HUMAN_DESIGN}?client_reference_id=demo_user&success_url=${window.location.origin}?payment_success=human_design`;
            break;
    }

    // fallback if link is empty (mock data not filled by user)
    if (link.includes('your_link')) {
        alert("Developer: You need to paste your Stripe Links in constants.ts for this to work.");
        setProcessing(false);
        return;
    }

    window.location.href = link;
  };

  const getTitle = () => {
    switch (type) {
      case 'CREDIT': return 'Purchase a Call Credit';
      case 'SUBSCRIPTION': return 'Monthly Subscription';
      case 'DONATION': return 'Donate to Call Bank';
      case 'EXTEND': return 'Extend Your Call';
      case 'HUMAN_DESIGN': return 'Human Design Reading';
    }
  };

  const getDescription = () => {
    switch (type) {
      case 'CREDIT': return `One 30-minute call with an Intuitive Mentor for $${COST_PER_CALL}.`;
      case 'SUBSCRIPTION': return `Daily calls for $${SUBSCRIPTION_COST}/month. Best value.`;
      case 'DONATION': return 'Help others access support by donating to the community Call Bank.';
      case 'EXTEND': return `Add another 30 minutes to your current conversation for $${COST_PER_CALL}.`;
      case 'HUMAN_DESIGN': return `A 2-hour in-depth analysis of your life strategy for $${HUMAN_DESIGN_COST}.`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-elegance/60 backdrop-blur-sm p-4">
      <div className="bg-brand-bg rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-xl font-bold text-elegance mb-2">{getTitle()}</h2>
          <p className="text-coney mb-6">{getDescription()}</p>

          <div className="flex gap-3">
            <button 
              onClick={onClose}
              disabled={processing}
              className="flex-1 py-3 px-4 rounded-xl border border-coney/30 text-coney font-medium hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handlePayment}
              disabled={processing}
              className="flex-1 py-3 px-4 rounded-xl bg-tiki text-white font-medium hover:bg-[#b05a3b] transition-colors flex justify-center items-center gap-2 shadow-lg shadow-tiki/20"
            >
              {processing ? 'Redirecting...' : 'Proceed to Stripe'}
            </button>
          </div>
          <p className="text-[10px] text-center text-coney mt-4">Secure payment processed by Stripe. You will be redirected back here after payment.</p>
        </div>
      </div>
    </div>
  );
};
