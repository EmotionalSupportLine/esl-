
export const COST_PER_CALL = 45;
export const PAY_PER_CALL = 20; // Amount mentor earns per call ($40/hr equivalent)
export const SUBSCRIPTION_COST = 299;
export const HUMAN_DESIGN_COST = 555;
export const CALL_DURATION_SECONDS = 30 * 60; // 30 minutes
export const WARNING_TIME_SECONDS = 5 * 60; // 5 minutes left
export const CRISIS_HOTLINE_NUMBER = "988";
export const MEDITATION_AUDIO_URL = "https://cdn.pixabay.com/download/audio/2022/03/09/audio_c8c917b11d.mp3?filename=singing-bowl-meditation-19793.mp3";
export const TWILIO_PHONE_NUMBER = "+17205137242";

// --- PASTE YOUR GOOGLE CALENDAR APPOINTMENT LINK HERE ---
export const GOOGLE_CALENDAR_LINK = "https://calendar.app.google/gczW5R1ubjrYmJo7A"; 

// --- PASTE YOUR 2-HOUR HUMAN DESIGN CALENDAR LINK HERE ---
export const GOOGLE_CALENDAR_HUMAN_DESIGN_LINK = "https://calendar.app.google/eWoLjMqAFaKbd9cz6";

// Safety keywords that trigger interceptors
export const SAFETY_KEYWORDS = {
    SUICIDE: ['suicide', 'kill myself', 'want to die', 'end it all', 'harm myself'],
    SEXUAL: ['sex', 'nude', 'naked', 'masturbate', 'horny', 'jerk off']
};

// Fallback resources if DB connection fails
export const INITIAL_AFFILIATE_RESOURCES = [
    {
        id: 'gut_health',
        keywords: ['gut', 'stomach', 'digestion', 'bloating', 'follicle'],
        label: 'Gut Health Follicle Test',
        text: 'I mentioned a test that helped me. It analyzes hair follicles to map gut health:',
        url: 'https://example.com/PASTE_YOUR_GUT_HEALTH_LINK_HERE' 
    },
    {
        id: 'grounding',
        keywords: ['grounding', 'earthing', 'sleep', 'anxiety', 'nature'],
        label: 'Earthing/Grounding Mat',
        text: 'This grounding mat helps regulate the nervous system while sleeping:',
        url: 'https://example.com/PASTE_YOUR_EARTHING_LINK_HERE'
    },
    {
        id: 'magnesium',
        keywords: ['muscle', 'tension', 'sleep', 'relax', 'cramps'],
        label: 'Magnesium Spray',
        text: 'A pure magnesium spray can really help with that physical tension:',
        url: 'https://example.com/PASTE_YOUR_MAGNESIUM_LINK_HERE'
    }
];

// --- YOU MUST PASTE YOUR SUPABASE KEYS HERE ---
export const SUPABASE_CONFIG = {
    URL: "https://dvcadhxahjkoxxszakar.supabase.co",
    ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR2Y2FkaHhhaGprb3h4c3pha2FyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUzMTQ1MjAsImV4cCI6MjA4MDg5MDUyMH0.32nwgVWojN3efiXHYLg-3EhCxXzM0b8-ME9VDd4o9-w"
};

// --- YOU MUST PASTE YOUR STRIPE LINKS HERE ---
export const STRIPE_LINKS = {
    SINGLE_CALL: "https://book.stripe.com/bJeaEX14WbQEaDm8zh0kE0b",
    SUBSCRIPTION: "https://buy.stripe.com/fZudR9eVMaMA4eYbLt0kE0a",
    DONATION: "https://donate.stripe.com/3cI9AT8xo4occLu2aT0kE0c",
    HUMAN_DESIGN: "https://book.stripe.com/dRmeVd6pg8EsbHq9Dl0kE09"
};

// BETA TESTING: Only ONE Supporter (The Admin) exists to ensure calls route correctly.
export const INITIAL_SUPPORTERS = [
  { 
    id: 's_me', 
    name: 'Magdalene', 
    bio: 'Intuitive Mentor specializing in career blocks, soul purpose, and imposter syndrome. I will help you validate your path.', 
    isAvailable: false, // Defaulting to FALSE (OFF) as explicitly requested
    tags: ['Career Intuition', 'Soul Purpose', 'Anxiety', 'Human Design'],
    earnings: 120,
    avatar: 'https://ui-avatars.com/api/?name=Magdalene&background=eacfb9&color=524c4f',
    calendarUrl: GOOGLE_CALENDAR_LINK,
    shifts: [
        { id: 'sh1', day: 'Mon', time: '9:00 AM - 5:00 PM' },
        { id: 'sh2', day: 'Tue', time: '9:00 AM - 5:00 PM' },
        { id: 'sh3', day: 'Wed', time: '9:00 AM - 5:00 PM' },
        { id: 'sh4', day: 'Thu', time: '9:00 AM - 5:00 PM' },
        { id: 'sh5', day: 'Fri', time: '9:00 AM - 5:00 PM' }
    ],
    blockedCallerIds: []
  }
];

export const INITIAL_OPEN_SHIFTS = [
    { id: 'os1', day: 'Friday', time: '6:00 PM - 10:00 PM', isClaimed: false },
    { id: 'os2', day: 'Saturday', time: '10:00 AM - 2:00 PM', isClaimed: false },
    { id: 'os3', day: 'Sunday', time: '12:00 PM - 4:00 PM', isClaimed: true, claimedBy: 'Magdalene' }
];
