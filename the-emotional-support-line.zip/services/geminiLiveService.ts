
import { Device, Call } from '@twilio/voice-sdk';

export class VoiceService {
  private device: Device | null = null;
  private call: Call | null = null;
  private token: string | null = null;
  private isInitialized: boolean = false;
  private incomingCallHandler: ((call: Call) => void) | null = null;

  constructor() {}

  setIncomingCallHandler(handler: ((call: Call) => void) | null) {
      this.incomingCallHandler = handler;
  }

  async initialize(identity: string) {
    // If already initialized and token is valid, don't re-run
    if (this.isInitialized && this.device?.state === 'registered') {
        console.log("Twilio Device already active");
        return;
    }

    try {
        console.log(`Fetching token for: ${identity}...`);
        const response = await fetch(`/api/token?identity=${identity}`);
        
        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || `Server returned ${response.status}`);
        }

        const data = await response.json();
        this.token = data.token;

        if (!this.token) throw new Error("Server returned an empty token.");

        // Clean up old device if it exists
        if (this.device) {
          this.device.destroy();
        }

        this.device = new Device(this.token, {
            codecPreferences: ['opus', 'pcmu'] as any,
            enableRingingState: true
        } as any);

        // Set up device listeners
        this.device.on('registered', () => {
            console.log('Twilio Device Registered & Ready');
            this.isInitialized = true;
        });
        
        this.device.on('unregistered', () => {
            console.log('Twilio Device Unregistered');
            this.isInitialized = false;
        });

        this.device.on('error', (error) => {
            console.error('Twilio Device Error:', error.message);
            this.isInitialized = false;
        });
        
        this.device.on('incoming', (call) => {
            console.log("Incoming call from:", call.parameters.From);
            if (this.incomingCallHandler) {
                this.incomingCallHandler(call);
            } else {
                call.reject();
            }
        });

        // Register to start receiving calls
        await this.device.register();

    } catch (err: any) {
        console.error("Twilio Init Failed:", err.message);
        this.isInitialized = false;
        throw err; 
    }
  }

  async connect(recipientId: string): Promise<boolean> {
    if (!this.device || !this.isInitialized) {
        console.error("Cannot connect: Device not ready");
        return false;
    }
    
    try {
        this.call = await this.device.connect({ 
            params: { To: recipientId } 
        });
        this.setupCallListeners();
        return true;
    } catch (err) {
        console.error("Connect failed", err);
        return false;
    }
  }

  acceptIncomingCall(call: Call) {
      this.call = call;
      this.call.accept();
      this.setupCallListeners();
  }

  private setupCallListeners() {
      if (!this.call) return;
      this.call.on('accept', () => console.log('Call established'));
      this.call.on('disconnect', () => {
          console.log('Call ended');
          this.call = null;
      });
  }

  disconnect() {
    if (this.call) {
        this.call.disconnect();
        this.call = null;
    }
  }

  isActive() {
    return !!this.call;
  }

  destroy() {
    if (this.device) {
      this.device.destroy();
      this.device = null;
      this.isInitialized = false;
    }
  }
}

export const voiceService = new VoiceService();
