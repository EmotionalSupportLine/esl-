
import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../contexts/AppContext';
import { UserRole, CallState } from '../types';
import { PaymentModal } from './PaymentModal';
import { Scheduler } from './Scheduler';

export const Dashboard = () => {
  const { 
    user, 
    setActiveCallState, 
    supporters, 
    connectToFirstAvailable,
    supporterCashOut,
    addShift,
    removeShift,
    toggleSupporterAvailability,
  } = useApp();

  const [showPayModal, setShowPayModal] = useState<'CREDIT' | 'SUBSCRIPTION' | 'DONATION' | 'HUMAN_DESIGN' | null>(null);
  const [schedulingWith, setSchedulingWith] = useState<{id: string, name: string, calendarUrl?: string, reason?: string} | null>(null);
  const [viewMode, setViewMode] = useState<UserRole>(user?.role || UserRole.CALLER);
  const [connecting, setConnecting] = useState(false);
  const [shiftTime, setShiftTime] = useState('');
  const [shiftDay, setShiftDay] = useState('Mon');

  useEffect(() => {
    if (user?.role) setViewMode(user.role);
  }, [user?.role]);

  const handleAddShiftClick = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!shiftTime.trim()) return;
    
    let finalTime = shiftTime;
    if (shiftTime.includes(':')) {
      const parts = shiftTime.split(':');
      const hour = parseInt(parts[0]);
      if (!isNaN(hour)) {
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const h12 = hour % 12 || 12;
        const mins = (parts[1] || '00').replace(/\D/g, '').substring(0, 2);
        finalTime = `${h12}:${mins.padStart(2, '0')} ${ampm}`;
      }
    }
    
    addShift('s_me', shiftDay, finalTime);
    setShiftTime('');
  };

  const handleQuickCall = async () => {
    setConnecting(true);
    // Visual feedback delay
    await new Promise(r => setTimeout(r, 800));
    
    const result = connectToFirstAvailable();
    if (result === 'CONNECTED') {
      setActiveCallState(CallState.ACTIVE);
    } else {
        if (result === 'NO_MENTORS') {
            // Find Magdalene to get her calendar link
            const magdalene = supporters.find(s => s.id === 's_me');
            setSchedulingWith({
                id: magdalene?.id || 's_me', 
                name: magdalene?.name || 'Magdalene', 
                calendarUrl: magdalene?.calendarUrl,
                reason: "NO_ONE_ONLINE"
            });
        } else if (result === 'NO_CREDITS') {
            setShowPayModal('CREDIT');
        }
    }
    setConnecting(false);
  };

  const myProfile = supporters.find(s => s.id === 's_me');
  
  const displaySupporters = useMemo(() => {
    if (user?.role === UserRole.SUPPORTER || user?.role === UserRole.ADMIN) {
        return supporters.filter(s => s.id !== user.id);
    }
    return supporters;
  }, [supporters, user]);

  return (
    <div className="pb-24 max-w-6xl mx-auto px-4">
      {viewMode === UserRole.SUPPORTER && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-buff flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <h2 className="text-2xl font-bold text-elegance">Mentor Hub</h2>
              <p className="text-coney text-sm">Status: <span className={myProfile?.isAvailable ? "text-green-500 font-bold" : "text-gray-400 font-bold"}>{myProfile?.isAvailable ? 'Receiving Calls' : 'Offline'}</span></p>
            </div>
            <button 
              onClick={() => toggleSupporterAvailability('s_me')}
              className={`w-full md:w-auto px-12 py-4 rounded-2xl font-black tracking-widest transition-all shadow-xl active:scale-95 ${myProfile?.isAvailable ? 'bg-green-500 text-white shadow-green-100' : 'bg-gray-200 text-gray-500'}`}
            >
              {myProfile?.isAvailable ? '● ONLINE' : '○ GO ONLINE'}
            </button>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-buff">
              <h3 className="font-bold text-lg mb-6 text-elegance">Account Balance</h3>
              <div className="p-8 bg-elegance rounded-3xl text-white relative overflow-hidden">
                <p className="text-xs opacity-70 uppercase tracking-widest mb-1 font-bold">Earnings to date</p>
                <p className="text-6xl font-bold mb-8">${myProfile?.earnings || 0}</p>
                <button onClick={supporterCashOut} className="w-full bg-tiki py-4 rounded-2xl font-bold text-sm hover:bg-[#b05a3b] transition-colors relative z-10 shadow-lg">Request Payout</button>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-buff">
              <h3 className="font-bold text-lg mb-6 text-elegance">Quick Shift Entry</h3>
              <div className="space-y-6">
                <form onSubmit={handleAddShiftClick} className="flex flex-col gap-3">
                  <div className="flex gap-2">
                    <select 
                      value={shiftDay} 
                      onChange={e => setShiftDay(e.target.value)} 
                      className="bg-gray-50 border border-buff p-4 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-dragonfly outline-none"
                    >
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                    <input 
                      type="text" 
                      placeholder="e.g. 10am-2pm" 
                      value={shiftTime} 
                      onChange={e => setShiftTime(e.target.value)} 
                      className="flex-1 bg-gray-50 border border-buff p-4 rounded-2xl text-sm focus:ring-2 focus:ring-dragonfly outline-none" 
                    />
                  </div>
                  <button type="submit" className="w-full bg-dragonfly text-white py-4 rounded-2xl font-bold text-sm shadow-md active:scale-95">Add Shift to Schedule</button>
                </form>
                
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                  {myProfile?.shifts?.map(s => (
                    <div key={s.id} className="flex justify-between items-center bg-slate-50 p-4 rounded-2xl text-sm border border-buff/30 animate-in slide-in-from-left-2">
                      <span className="font-bold text-elegance">{s.day}: {s.time}</span>
                      <button onClick={() => removeShift('s_me', s.id)} className="text-red-400 font-bold p-2 hover:text-red-600 transition-colors">✕</button>
                    </div>
                  ))}
                  {(!myProfile?.shifts || myProfile.shifts.length === 0) && (
                    <p className="text-center text-coney text-xs py-10 italic">Your shift schedule is empty.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {viewMode === UserRole.CALLER && (
        <div className="space-y-8 animate-in fade-in">
          <div className="bg-gradient-to-r from-dragonfly to-coney rounded-3xl p-10 text-white shadow-2xl relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
              <div className="text-center md:text-left">
                <h2 className="text-4xl font-bold mb-2">Welcome Back</h2>
                <p className="text-buff font-medium text-lg">{user?.isSubscriber ? "Unlimited Mentor Access" : `${user?.credits || 0} credits available`}</p>
              </div>
              <button 
                onClick={handleQuickCall} 
                disabled={connecting} 
                className="px-10 py-5 bg-tiki text-white rounded-3xl font-black shadow-2xl hover:scale-105 transition-all disabled:opacity-50 flex items-center justify-center gap-3 active:scale-95"
              >
                {connecting ? <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin" /> : <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>}
                Talk to Someone Now
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displaySupporters.map(s => (
              <div key={s.id} className="bg-white border border-buff/50 rounded-3xl p-8 flex flex-col shadow-sm hover:shadow-xl transition-all border-b-4 border-b-buff/20">
                <div className="flex items-center gap-4 mb-6">
                  <img src={s.avatar} alt={s.name} className="w-16 h-16 rounded-full border-2 border-buff shadow-sm" />
                  <div>
                    <h4 className="font-bold text-xl text-elegance">{s.name}</h4>
                    <div className={`flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded-full border uppercase font-black tracking-widest ${s.isAvailable ? 'text-green-500 border-green-200 bg-green-50' : 'text-gray-300 border-gray-100 bg-gray-50'}`}>
                      {s.isAvailable && <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-dot-pulse" />}
                      <span>{s.isAvailable ? 'Available' : 'Busy'}</span>
                    </div>
                  </div>
                </div>
                <p className="text-coney text-sm mb-8 line-clamp-4 leading-relaxed italic">"{s.bio}"</p>
                <div className="mt-auto space-y-3">
                  <button 
                    disabled={!s.isAvailable} 
                    onClick={handleQuickCall}
                    className={`w-full py-4 rounded-2xl font-bold transition-all active:scale-95 ${s.isAvailable ? 'bg-dragonfly text-white shadow-lg shadow-dragonfly/20' : 'bg-gray-100 text-gray-400'}`}
                  >
                    Connect Now
                  </button>
                  <button 
                    onClick={() => setSchedulingWith({id: s.id, name: s.name, calendarUrl: s.calendarUrl})}
                    className="w-full py-3 border border-buff text-coney rounded-2xl text-xs font-bold hover:bg-slate-50 transition-colors"
                  >
                    {s.isAvailable ? 'View Schedule' : 'Schedule Call Back'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {(user?.role === UserRole.ADMIN || user?.role === UserRole.SUPPORTER) && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/95 backdrop-blur-xl border border-buff z-50 px-8 py-3 flex gap-8 rounded-full shadow-2xl">
          {user?.role === UserRole.ADMIN && (
            <button onClick={() => setViewMode(UserRole.ADMIN)} className={`text-[10px] font-black uppercase tracking-widest transition-colors ${viewMode === UserRole.ADMIN ? 'text-tiki' : 'text-gray-400'}`}>Admin</button>
          )}
          <button onClick={() => setViewMode(UserRole.SUPPORTER)} className={`text-[10px] font-black uppercase tracking-widest transition-colors ${viewMode === UserRole.SUPPORTER ? 'text-tiki' : 'text-gray-400'}`}>Mentor Hub</button>
          <button onClick={() => setViewMode(UserRole.CALLER)} className={`text-[10px] font-black uppercase tracking-widest transition-colors ${viewMode === UserRole.CALLER ? 'text-tiki' : 'text-gray-400'}`}>Caller View</button>
        </div>
      )}
      
      {showPayModal && <PaymentModal type={showPayModal} onClose={() => setShowPayModal(null)} />}
      {schedulingWith && (
        <Scheduler 
            supporterId={schedulingWith.id} 
            supporterName={schedulingWith.name} 
            calendarUrl={schedulingWith.calendarUrl} 
            onClose={() => setSchedulingWith(null)} 
            noMentorsAvailable={schedulingWith.reason === 'NO_ONE_ONLINE'}
        />
      )}
    </div>
  );
};
