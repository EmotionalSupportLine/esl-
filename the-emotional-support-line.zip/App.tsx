
import React from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { ActiveCall } from './components/ActiveCall';
import { MentorApplicationForm } from './components/MentorApplication'; 
import { CallState, UserRole, ApplicationState } from './types';
import { COST_PER_CALL, SUBSCRIPTION_COST } from './constants';

const AppContent = () => {
  const { user, login, activeCallState, applicationState } = useApp();

  // 1. Priority: Active Call
  if (activeCallState === CallState.ACTIVE || activeCallState === CallState.POST_CALL) {
    return <ActiveCall />;
  }

  // 2. Priority: Application Form
  if (applicationState === ApplicationState.VIEWING) {
      return (
          <Layout>
              <MentorApplicationForm />
          </Layout>
      );
  }

  if (applicationState === ApplicationState.SUBMITTED) {
      return (
          <Layout>
              <div className="max-w-md mx-auto text-center py-16 space-y-6">
                  <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto text-4xl">✓</div>
                  <h2 className="text-3xl font-bold text-elegance">Application Received</h2>
                  <p className="text-coney">Thank you for applying to be an Intuitive Mentor. We have received your signed agreement and will review your application shortly.</p>
                  <button onClick={() => window.location.reload()} className="text-dragonfly font-bold underline">Return Home</button>
              </div>
          </Layout>
      );
  }

  // 3. Default: Landing Page or Dashboard
  return (
    <Layout>
      {!user ? (
        <div className="flex flex-col items-center justify-center py-10 md:py-16 text-center space-y-12 animate-in fade-in duration-700">
          
          {/* Hero Section */}
          <p className="text-brand-teal font-black uppercase tracking-[0.5em] text-xs md:text-sm -mb-6 animate-in fade-in slide-in-from-top-4 duration-1000">
            Intuitive Mentoring & Reality Checks
          </p>
          <div className="max-w-5xl w-full bg-buff/10 p-12 md:p-16 rounded-[3rem] space-y-8 border border-buff/20 shadow-inner">
            <h2 className="text-5xl md:text-7xl font-bold text-elegance tracking-tight leading-tight">
              Real connection,<br />
              <span className="text-brand-teal bg-brand-teal/10 px-2 rounded-lg decoration-clone">right now.</span>
            </h2>
            <p className="text-xl md:text-2xl text-elegance leading-relaxed max-w-3xl mx-auto">
              Get emotional support, validation, or a gentle reality check from <strong>Intuitive Mentors</strong>. 
              No judgment. No waitlists. Just active support.
            </p>
          </div>

          {/* Side-by-Side Pricing Options */}
          <div className="grid md:grid-cols-2 gap-6 w-full max-w-4xl px-4">
              {/* Option 1: Single Call */}
              <div className="bg-white p-8 rounded-3xl border-4 border-brand-orange ring-4 ring-brand-orange/10 shadow-lg flex flex-col items-center transition-transform hover:-translate-y-1">
                 <h3 className="text-xl font-bold text-brand-orange uppercase tracking-widest mb-2">Single Session</h3>
                 <div className="text-4xl font-bold text-elegance mb-4">${COST_PER_CALL}<span className="text-lg font-normal text-coney">/call</span></div>
                 <p className="text-coney text-sm mb-8">One 30-minute focused session with the first available Mentor.</p>
                 <button 
                    onClick={() => login(UserRole.CALLER)}
                    className="w-full py-3 border-2 border-brand-orange text-brand-orange rounded-xl font-bold hover:bg-brand-orange hover:text-white transition-all"
                 >
                    Book One Session
                 </button>
              </div>

              {/* Option 2: Subscription (Highlighted) */}
              <div className="bg-brand-orange p-8 rounded-3xl shadow-xl flex flex-col items-center text-white transform scale-105 border-4 border-white ring-4 ring-brand-orange/20 relative overflow-hidden">
                 <div className="absolute top-0 right-0 bg-white text-brand-orange text-sm font-black px-5 py-2 rounded-bl-2xl shadow-md uppercase tracking-wider">Best Value</div>
                 <h3 className="text-xl font-bold text-elegance uppercase tracking-widest mb-2">Unlimited Access</h3>
                 <div className="text-4xl font-bold text-white mb-4">${SUBSCRIPTION_COST}<span className="text-sm italic font-serif opacity-80 ml-1">/ month</span></div>
                 <p className="text-white/90 text-sm mb-8">Daily calls. Priority scheduling. The ultimate commitment to your growth.</p>
                 <button 
                    onClick={() => login(UserRole.CALLER)}
                    className="w-full py-5 bg-white text-brand-orange rounded-2xl font-black text-xl hover:bg-buff transition-all shadow-2xl animate-soft-pulse active:scale-95"
                 >
                    Get Unlimited Access
                 </button>
              </div>
          </div>

          {/* Value Props */}
          <div className="w-full max-w-5xl px-4">
            <div className="grid grid-cols-2 gap-8 p-10 bg-white/50 backdrop-blur-sm rounded-[3rem] border border-buff/30 shadow-sm">
               <div className="flex flex-col items-center text-center space-y-3 group">
                  <div className="w-16 h-16 bg-brand-teal/10 rounded-2xl flex items-center justify-center text-brand-teal group-hover:scale-110 transition-transform duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                  </div>
                  <div>
                    <div className="font-bold text-3xl text-elegance mb-1">Human</div>
                    <div className="text-lg text-coney font-medium leading-relaxed">Real people, not AI bots.</div>
                  </div>
               </div>
               <div className="flex flex-col items-center text-center space-y-3 group">
                  <div className="w-16 h-16 bg-brand-teal/10 rounded-2xl flex items-center justify-center text-brand-teal group-hover:scale-110 transition-transform duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
                  </div>
                  <div>
                    <div className="font-bold text-3xl text-elegance mb-1">Intuitive</div>
                    <div className="text-lg text-coney font-medium leading-relaxed">Active feedback & guidance.</div>
                  </div>
               </div>
               <div className="flex flex-col items-center text-center space-y-3 group">
                  <div className="w-16 h-16 bg-brand-teal/10 rounded-2xl flex items-center justify-center text-brand-teal group-hover:scale-110 transition-transform duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>
                  </div>
                  <div>
                    <div className="font-bold text-3xl text-elegance mb-1">Private</div>
                    <div className="text-lg text-coney font-medium leading-relaxed">100% Confidential.</div>
                  </div>
               </div>
               <div className="flex flex-col items-center text-center space-y-3 group">
                  <div className="w-16 h-16 bg-brand-teal/10 rounded-2xl flex items-center justify-center text-brand-teal group-hover:scale-110 transition-transform duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                  </div>
                  <div>
                    <div className="font-bold text-3xl text-elegance mb-1">Impact</div>
                    <div className="text-lg text-coney font-medium leading-relaxed">Donations support others.</div>
                  </div>
               </div>
            </div>
          </div>

        </div>
      ) : (
        <Dashboard />
      )}
    </Layout>
  );
};

const App = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
