import React from 'react';
import { useApp } from '../contexts/AppContext';
import { UserRole, ApplicationState } from '../types';

export const Layout = ({ children }: { children?: React.ReactNode }) => {
  const { user, logout, callBankBalance, notifications, removeNotification, login, setApplicationState } = useApp();
  
  const handleProtectedLogin = (role: UserRole) => {
      const code = window.prompt("Enter Access Code:");
      if (code === "333") { 
          login(role);
      } else if (code) {
          alert("Incorrect Access Code");
      }
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-bg relative text-elegance font-sans selection:bg-dragonfly selection:text-white">
      {/* Toast Notifications */}
      <div className="fixed top-24 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {notifications.map(note => (
          <div 
             key={note.id} 
             className="bg-coney/90 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-right max-w-xs pointer-events-auto border border-white/10"
          >
             <div className="flex-1 text-sm font-medium">{note.message}</div>
             <button onClick={() => removeNotification(note.id)} className="text-buff hover:text-white transition-colors">✕</button>
          </div>
        ))}
      </div>

      {/* Disclaimer Bar */}
      <div className="bg-buff/30 text-tiki text-[10px] md:text-xs py-2 px-4 text-center font-bold border-b border-buff/50">
        ⚠️ Intuitive Mentoring/Coaching service only. NOT a clinical or medical service. Please call <a href="tel:988" className="underline hover:text-dragonfly">988</a> if you are experiencing a mental health emergency.
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-black/5 bg-white/70 backdrop-blur-xl transition-all duration-300">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            
            {/* Logo Section */}
            <div className="flex items-center gap-3">
              <img 
                src="/logo.png" 
                alt="The Emotional Support Line Logo" 
                className="w-10 h-10 md:w-12 md:h-12 object-contain"
              />
              <div className="flex flex-col">
                <h1 className="text-xl md:text-2xl font-black text-elegance tracking-tight leading-none">The Emotional Support Line</h1>
                <p className="text-[10px] text-elegance uppercase tracking-widest font-bold mt-0.5">Intuitive Mentor Platform</p>
              </div>
            </div>
            
            {/* Right Actions */}
            <div className="flex items-center gap-4 md:gap-6">
               <div className="flex flex-col items-end bg-tiki/10 px-4 py-2 rounded-2xl border border-tiki/20 shadow-sm">
                  <span className="text-tiki/70 uppercase tracking-wider text-[8px] md:text-[10px] font-black">Donation Bank</span>
                  <span className="font-bold text-tiki text-sm md:text-base">${callBankBalance.toLocaleString()}</span>
               </div>

              {user ? (
                <div className="flex items-center gap-3">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-semibold text-elegance">{user.name}</p>
                    <p className="text-xs text-coney">{user.role === 'CALLER' ? (user.isSubscriber ? 'Subscriber' : `${user.credits} Credits`) : (user.role === 'ADMIN' ? 'Admin' : 'Intuitive Mentor')}</p>
                  </div>
                  <button onClick={logout} className="text-xs font-medium bg-gray-100 hover:bg-gray-200 text-elegance px-4 py-2 rounded-full transition-all">Logout</button>
                </div>
              ) : (
                <a href="https://www.theemotionalsupportline.com" className="text-sm font-bold text-elegance hover:text-dragonfly transition-colors flex items-center gap-1"><span className="hidden md:inline">Back to </span>Website</a>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 md:py-12 fade-in">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-elegance text-white mt-auto">
        <div className="max-w-6xl mx-auto px-4 py-20 text-center space-y-10">
          <div className="flex flex-col items-center gap-4">
             <p className="font-black text-2xl md:text-3xl tracking-tighter">The Emotional Support Line &copy; {new Date().getFullYear()}</p>
             <div className="flex flex-wrap justify-center gap-8 text-base font-bold text-buff/80">
                 <a href="#" className="hover:text-white transition-all hover:scale-110">Terms of Service</a>
                 <span className="text-white/20">|</span>
                 <a href="#" className="hover:text-white transition-all hover:scale-110">Privacy Policy</a>
             </div>
          </div>
          
          <div className="max-w-4xl mx-auto space-y-6">
            <p className="text-sm md:text-base text-white/70 leading-relaxed font-medium">
              The Emotional Support Line connects subscribers with Intuitive Mentors for emotional validation and reality checks. 
              Mentors are peer coaches, not licensed medical professionals. Calls are monitored for safety and quality assurance.
            </p>
            <div className="flex flex-col items-center gap-2">
              <div className="h-px w-24 bg-tiki/50 mb-2"></div>
              <p className="text-xs md:text-sm text-tiki font-black uppercase tracking-[0.3em]">
                Empowering Clarity Through Connection
              </p>
            </div>
          </div>

          <div className="flex justify-center items-center gap-8 mt-12 pt-12 border-t border-white/10 w-fit mx-auto">
                {!user && (
                    <>
                        <button onClick={() => setApplicationState(ApplicationState.VIEWING)} className="text-sm text-brand-teal hover:text-tiki transition-colors uppercase tracking-widest font-black">Join Our Team</button>
                        <span className="text-white/10">|</span>
                        <button onClick={() => handleProtectedLogin(UserRole.SUPPORTER)} className="text-xs text-white/40 hover:text-white transition-colors uppercase tracking-widest font-bold">Mentor Login</button>
                        <span className="text-white/10">|</span>
                        <button onClick={() => handleProtectedLogin(UserRole.ADMIN)} className="text-xs text-white/40 hover:text-white transition-colors uppercase tracking-widest font-bold">Admin Access</button>
                    </>
                )}
            </div>
        </div>
      </footer>
    </div>
  );
};