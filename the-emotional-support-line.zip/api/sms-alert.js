
const twilio = require('twilio');

module.exports = async (request, response) => {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const secret = process.env.TWILIO_API_SECRET;
  
  if (!sid || !secret) {
      console.error("Missing Twilio credentials in environment.");
      return response.status(500).json({ error: "Server Configuration Error" });
  }

  const client = twilio(sid, secret, { accountSid: sid });
  const { message } = request.body;

  try {
      // Send text to YOUR personal number (The Admin)
      const adminNumber = process.env.ADMIN_PHONE || '+19704437052'; 

      await client.messages.create({
          body: `🔔 ESL Alert: ${message}`,
          from: process.env.TWILIO_PHONE_NUMBER, 
          to: adminNumber
      });

      response.status(200).json({ success: true });
  } catch (error) {
      console.error("SMS Alert Error", error);
      // Don't leak error details to client, just log them
      response.status(500).json({ error: "Failed to send alert" });
  }
};
