
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_CONFIG } from '../constants';

// This safely initializes Supabase only if keys are present
// Prevents app crash for DIY setup before keys are added
export const supabase = (SUPABASE_CONFIG.URL.includes("YOUR_SUPABASE") || SUPABASE_CONFIG.ANON_KEY.includes("YOUR_SUPABASE"))
    ? null 
    : createClient(SUPABASE_CONFIG.URL, SUPABASE_CONFIG.ANON_KEY);
