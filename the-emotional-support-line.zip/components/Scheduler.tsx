
import React from 'react';
import { useApp } from '../contexts/AppContext';
import { MEDITATION_AUDIO_URL, GOOGLE_CALENDAR_LINK } from '../constants';

interface SchedulerProps {
    supporterName: string;
    supporterId: string;
    calendarUrl?: string;
    onClose: () => void;
    noMentorsAvailable?: boolean;
}

export const Scheduler: React.FC<SchedulerProps> = ({ 
    supporterName, 
    calendarUrl, 
    onClose, 
    noMentorsAvailable 
}) => {
    // Always fallback to the global link to ensure a button is visible
    const finalCalendarUrl = calendarUrl || GOOGLE_CALENDAR_LINK;
  
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-elegance/80 p-4 backdrop-blur-xl animate-in fade-in duration-300">
        <div className="bg-brand-bg rounded-[2.5rem] shadow-2xl max-w-xl w-full border border-buff overflow-hidden animate-in zoom-in-95 duration-300">
           
           {/* HEADER */}
           <div className="bg-dragonfly/10 p-5 border-b border-buff/30 flex justify-between items-center">
               <div className="flex items-center gap-3">
                   <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl shadow-lg ${noMentorsAvailable ? 'bg-tiki text-white' : 'bg-dragonfly text-white'}`}>
                        {noMentorsAvailable ? '📞' : '📅'}
                   </div>
                   <div>
                       <h3 className="text-sm font-black uppercase tracking-widest text-dragonfly">
                           {noMentorsAvailable ? 'No Mentors Currently Online' : 'Booking Concierge'}
                       </h3>
                       <p className="text-[10px] text-coney font-bold">
                           {noMentorsAvailable ? 'Securely Schedule a Session Below' : 'Secure Appointment System'}
                       </p>
                   </div>
               </div>
               <button onClick={onClose} className="w-10 h-10 rounded-full flex items-center justify-center text-coney hover:bg-buff/20 transition-colors">✕</button>
           </div>

           <div className="p-8 md:p-10 text-center">
                <div className="mb-8">
                    <h3 className="text-3xl font-bold text-elegance mb-3 leading-tight">
                        {noMentorsAvailable ? 'Schedule a Call Back' : `Schedule with ${supporterName}`}
                    </h3>
                    
                    {/* The specific message requested: "no mentors are currently available. Book a session below." */}
                    <div className="bg-tiki/10 p-4 rounded-2xl border border-tiki/20 mb-6 inline-block w-full">
                        <p className="text-tiki font-bold text-sm">
                            No mentors are currently available. Book a session below.
                        </p>
                    </div>
                    
                    <p className="text-coney text-sm leading-relaxed max-w-sm mx-auto">
                        Please use the secure Workspace Calendar below to select your preferred time slot. You will receive a confirmation and be connected as soon as your appointment starts.
                    </p>
                </div>

                <div className="space-y-8">
                    {/* THE CALENDAR GATEWAY */}
                    <div className="bg-white border-2 border-buff/40 rounded-3xl p-8 shadow-inner flex flex-col items-center gap-6">
                        <div className="flex -space-x-2">
                            <div className="w-14 h-14 rounded-full border-4 border-white bg-buff flex items-center justify-center text-2xl shadow-md">✨</div>
                            <div className="w-14 h-14 rounded-full border-4 border-white bg-dragonfly flex items-center justify-center text-2xl shadow-md">🦅</div>
                        </div>
                        
                        <div className="space-y-2">
                            <p className="text-xs font-black uppercase tracking-widest text-dragonfly tracking-tighter">Gateway to Magdalene's Calendar</p>
                            <p className="text-sm text-coney italic">"Select a time that works for your schedule."</p>
                        </div>

                        {/* THIS IS THE PRIMARY ACTION BUTTON POINTING TO THE CALENDAR LINK */}
                        <a 
                            href={finalCalendarUrl} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            onClick={onClose}
                            className="w-full py-5 bg-tiki text-white rounded-2xl font-black text-lg shadow-xl shadow-tiki/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 no-underline"
                        >
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>
                            Open Appointment Calendar
                        </a>
                    </div>
                    
                    <div className="flex flex-col gap-4">
                        <div className="flex items-center gap-3 justify-center mb-2">
                            <div className="h-px bg-buff/50 flex-1"></div>
                            <span className="text-[10px] font-black text-coney uppercase tracking-tighter">Frequency Support While You Wait</span>
                            <div className="h-px bg-buff/50 flex-1"></div>
                        </div>
                        <audio controls className="w-full h-10 opacity-70 hover:opacity-100 transition-opacity" src={MEDITATION_AUDIO_URL}>
                            Your browser does not support audio.
                        </audio>
                        <button type="button" onClick={onClose} className="text-xs text-coney font-bold underline decoration-buff underline-offset-4 hover:text-tiki">Close and go back</button>
                    </div>
                </div>
           </div>
        </div>
      </div>
    );
};
