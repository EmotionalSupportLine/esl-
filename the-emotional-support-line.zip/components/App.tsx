import React from 'react';
import { AppProvider, useApp } from '../contexts/AppContext';
import { Layout } from './Layout';
import { Dashboard } from './Dashboard';
import { ActiveCall } from './ActiveCall';
import { MentorApplicationForm } from './MentorApplication'; 
import { CallState, UserRole, ApplicationState } from '../types';
import { COST_PER_CALL, SUBSCRIPTION_COST } from '../constants';

const AppContent = () => {
  const { user, login, activeCallState, applicationState } = useApp();

  // 1. Priority: Active Call
  if (activeCallState === CallState.ACTIVE || activeCallState === CallState.POST_CALL) {
    return <ActiveCall />;
  }

  // 2. Priority: Application Form
  if (applicationState === ApplicationState.VIEWING) {
      return (
          <Layout>
              <MentorApplicationForm />
          </Layout>
      );
  }

  if (applicationState === ApplicationState.SUBMITTED) {
      return (
          <Layout>
              <div className="max-w-md mx-auto text-center py-16 space-y-6">
                  <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto text-4xl">✓</div>
                  <h2 className="text-3xl font-bold text-elegance">Application Received</h2>
                  <p className="text-coney">Thank you for applying to be an Intuitive Mentor. We have received your signed agreement and will review your application shortly.</p>
                  <button onClick={() => window.location.reload()} className="text-dragonfly font-bold underline">Return Home</button>
              </div>
          </Layout>
      );
  }

  // 3. Default: Landing Page or Dashboard
  return (
    <Layout>
      {!user ? (
        <div className="flex flex-col items-center justify-center py-10 md:py-16 text-center space-y-12 animate-in fade-in duration-700">
          
          {/* Hero Section */}
          <div className="max-w-4xl space-y-6">
            <h2 className="text-5xl md:text-7xl font-bold text-elegance tracking-tight leading-tight">
              Real connection,<br />
              <span className="text-brand-teal bg-brand-teal/10 px-2 rounded-lg decoration-clone">right now.</span>
            </h2>
            <p className="text-xl md:text-2xl text-coney leading-relaxed max-w-2xl mx-auto">
              Get emotional support, validation, or a gentle reality check from <strong>Intuitive Mentors</strong>. 
              No judgment. No waitlists. Just active support.
            </p>
          </div>

          {/* SEO Keywords Block (Visual) */}
          <div className="w-full overflow-hidden bg-buff/20 py-3 border-y border-buff/20">
              <p className="text-xs text-coney/70 font-medium uppercase tracking-widest mb-2">We support you with</p>
              <div className="flex flex-wrap justify-center gap-3 px-4 max-w-5xl mx-auto">
                  {["I cry every day", "Can't stop overthinking", "Panic attack help", "Feeling Overwhelmed", "Grief counseling", "Burnout", "Divorce support", "Soul Purpose", "Work Stress"].map(tag => (
                      <span key={tag} className="text-xs bg-white text-coney px-2 py-1 rounded-md shadow-sm border border-buff/30">{tag}</span>
                  ))}
                  <span className="text-xs text-coney/50 px-2 py-1">+ active listening</span>
              </div>
          </div>

          {/* Side-by-Side Pricing Options */}
          <div className="grid md:grid-cols-2 gap-6 w-full max-w-4xl px-4">
              {/* Option 1: Single Call */}
              <div className="bg-white p-8 rounded-3xl border-4 border-brand-orange ring-4 ring-brand-orange/10 shadow-lg flex flex-col items-center transition-transform hover:-translate-y-1">
                 <h3 className="text-xl font-bold text-brand-orange uppercase tracking-widest mb-2">Single Session</h3>
                 <div className="text-4xl font-bold text-elegance mb-4">${COST_PER_CALL}<span className="text-lg font-normal text-coney">/call</span></div>
                 <p className="text-coney text-sm mb-8">One 30-minute focused session with the first available Mentor.</p>
                 <button 
                    onClick={() => login(UserRole.CALLER)}
                    className="w-full py-3 border-2 border-brand-orange text-brand-orange rounded-xl font-bold hover:bg-brand-orange hover:text-white transition-all"
                 >
                    Book One Session
                 </button>
              </div>

              {/* Option 2: Subscription (Highlighted) */}
              <div className="bg-brand-orange p-8 rounded-3xl shadow-xl flex flex-col items-center text-white transform scale-105 border-4 border-white ring-4 ring-brand-orange/20 relative overflow-hidden">
                 <div className="absolute top-0 right-0 bg-white text-brand-orange text-sm font-black px-5 py-2 rounded-bl-2xl shadow-md uppercase tracking-wider">Best Value</div>
                 <h3 className="text-xl font-bold text-buff uppercase tracking-widest mb-2">Unlimited Access</h3>
                 <div className="text-4xl font-bold text-white mb-4">${SUBSCRIPTION_COST}<span className="text-lg font-normal text-white/70">/month</span></div>
                 <p className="text-white/90 text-sm mb-8">Daily calls. Priority scheduling. The ultimate commitment to your growth.</p>
                 <button 
                    onClick={() => login(UserRole.CALLER)}
                    className="w-full py-3 bg-white text-brand-orange rounded-xl font-bold hover:bg-buff transition-all shadow-lg"
                 >
                    Join Membership
                 </button>
              </div>
          </div>

          {/* Value Props */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl w-full pt-8 border-t border-buff/20">
             <div className="text-center">
                <div className="font-bold text-2xl text-dragonfly mb-1">Human</div>
                <div className="text-xs text-coney">Real people, not AI bots.</div>
             </div>
             <div className="text-center">
                <div className="font-bold text-2xl text-dragonfly mb-1">Intuitive</div>
                <div className="text-xs text-coney">Active feedback & guidance.</div>
             </div>
             <div className="text-center">
                <div className="font-bold text-2xl text-dragonfly mb-1">Private</div>
                <div className="text-xs text-coney">100% Confidential.</div>
             </div>
             <div className="text-center">
                <div className="font-bold text-2xl text-dragonfly mb-1">Impact</div>
                <div className="text-xs text-coney">Donations support others.</div>
             </div>
          </div>

        </div>
      ) : (
        <Dashboard />
      )}
    </Layout>
  );
};

const App = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;